GALAXY 철민 디펜더 - 휴대폰으로 클라우드 APK 빌드하기

준비물: Android 휴대폰, GitHub 계정, 인터넷 연결
주의: 이 패키지는 APK 자체가 아니라 APK를 클라우드에서 빌드하는 소스입니다.

1) https://github.com 에서 로그인하고 New repository를 눌러 새 저장소를 만듭니다.
   이름: galaxy-cheolmin-defender
   Public/Private 중 선택하고 Create repository를 누릅니다.
2) 저장소 화면에서 Add file > Upload files를 누릅니다.
3) 이 패키지 안의 game-source.zip 파일 하나를 업로드하고 Commit changes를 누릅니다.
4) 저장소에서 Add file > Create new file을 누릅니다.
5) 파일 이름 칸에 정확히 아래 경로를 입력합니다.
   .github/workflows/build-apk.yml
6) 이 패키지 안의 build-apk.yml 파일을 텍스트 편집기로 열고 전체 내용을 복사해 GitHub 편집창에 붙여넣습니다.
   (build-apk.yml을 파일로 업로드하는 것이 아니라, 위 경로의 새 파일 내용으로 붙여넣습니다.)
7) Commit changes를 누릅니다.
8) 저장소의 Actions 탭 > Build Android APK를 선택합니다.
   Run workflow가 보이면 눌러 실행합니다. 파일 업로드로 자동 실행되었으면 완료될 때까지 기다립니다.
9) 초록색 체크가 뜨면 해당 실행을 열고 맨 아래 Artifacts에서
   GALAXY-Cheolmin-Defender-APK를 다운로드합니다.
10) 내려받은 ZIP을 풀면 app-debug.apk가 나옵니다. 갤럭시에서 눌러 설치합니다.

중요한 점
- APK는 아직 생성된 것이 아닙니다. GitHub Actions가 성공해야 생성됩니다.
- GitHub Actions 무료 사용량/정책에 따라 실행 제한이 있을 수 있습니다.
- 설치 중 경고가 나오면 본인이 직접 만든 앱임을 확인한 경우에만 설치를 허용하세요.
- 이 APK는 개인 테스트용 debug 서명본입니다. 구글 플레이 정식 등록용이 아닙니다.
- 앱은 가로 화면이며 게임명은 GALAXY 철민 디펜더입니다.
- 광고/결제/온라인 기능은 포함되지 않았습니다.
